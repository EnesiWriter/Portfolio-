# Mustapha Enesi Ibrahim — Portfolio

> "Every brand has a story worth telling. Mine is one of learning to tell them well."

A narrative-driven portfolio website for Mustapha Enesi Ibrahim — Social Media Content Specialist, Digital Editor, and award-winning writer.

**Live site:** [your GitHub Pages URL here]

---

## About

This portfolio tells the story of a career built at the intersection of creative writing and strategic social media. Rather than listing credentials, it walks visitors through five chapters:

- **00 — Opening:** The central idea
- **01 — Origin:** Where it began (a blank page)
- **02 — The Craft:** What experience has built
- **03 — The Work:** Hydrogen Africa & Litro Media
- **04 — Recognition:** Awards & publications
- **05 — What's Next:** An invitation to connect

---

## Tech

Plain HTML, CSS, and vanilla JavaScript. No frameworks, no dependencies. Works everywhere.

- Custom cursor with smooth trail
- Scroll-triggered reveal animations
- Animated metric counters
- Publication ticker
- Reading progress bar
- Fully responsive

---

## Setup

### Option 1 — GitHub Pages (recommended)

1. Fork or clone this repository
2. Go to **Settings → Pages**
3. Set source to **Deploy from branch → main → / (root)**
4. Your site will be live at `https://yourusername.github.io/repository-name`

### Option 2 — Local Preview

Just open `index.html` in a browser. No build step needed.

---

## Customisation

| What | Where |
|---|---|
| All text content | `index.html` |
| Colours & fonts | `css/style.css` — edit `:root` variables |
| Animations | `js/script.js` |
| Portfolio images | `images/` folder |

### Updating Images

Replace the files in the `images/` folder:
- `hydrogen1.png`, `hydrogen2.png`, `hydrogen3.png` — Hydrogen Africa content
- `litro1.png`, `litro2.png`, `litro3.png` — Litro Media content

Image references in `index.html` use relative paths, so filenames must match.

---

## Contact

**Mustapha Enesi Ibrahim**
Lagos, Nigeria · Available for remote work

- Email: mennessie@gmail.com
- LinkedIn: [mustapha-enesi-ibrahim](https://linkedin.com/in/mustapha-enesi-ibrahim-8574051a0)
- Literary work: [linktr.ee/Eneesy](https://linktr.ee/Eneesy)
- Twitter / X: [@Eneessi](https://x.com/Eneessi)
